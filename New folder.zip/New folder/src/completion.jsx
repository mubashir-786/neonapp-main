export default function Completion() {
  return (
    <div>
      Thank your For your Payments Completion. This works absolutely fine.
    </div>
  );
}
