import { useParams } from "react-router-dom";
import { collections } from "./components/data/collections";
import ProductSmallCard from "./components/productSmallCard";
import ScrollToTopOnMount from "./components/scrolltoTop";

export default function Collection() {
  const { collectionId } = useParams();

  return (
    <div className="text-center my-16 ">
      <ScrollToTopOnMount />
      <h2 className="text-4xl text-pink font-bold">
        {collectionId} Collection
      </h2>
      <div className="flex flex-wrap gap-x-10 gap-y-16 w-11/12 my-20 items-center justify-center mx-auto">
        {collections.map((collection, i) => (
          <ProductSmallCard key={i} {...collection} />
        ))}
      </div>
    </div>
  );
}
