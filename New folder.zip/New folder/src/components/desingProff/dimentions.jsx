export default function Dimentions() {
  return (
    <div className="my-10">
      <h3 className="proffh3">Dimentions</h3>
      <div className="mt-6">
        <p className="font-bold">
          Length: <span className="font-normal">19"</span>
        </p>
        <p className="font-bold">
          Height: <span className="font-normal">14.5"</span>
        </p>
        <p>The sign will be custom made and size may vary slightly.</p>
        <p>The backboard adds a margin of about 0.8" around the text.</p>
      </div>
    </div>
  );
}
