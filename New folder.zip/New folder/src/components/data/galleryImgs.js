import img1 from "../../assets/gallery/img1.jpg";
import img2 from "../../assets/gallery/img2.png";
import img3 from "../../assets/gallery/img3.png";
import img4 from "../../assets/gallery/img4.png";
import img5 from "../../assets/gallery/img5.png";
import img6 from "../../assets/gallery/img6.png";

export const galleryImage = [
  { imgSource: img1 },
  { imgSource: img2 },
  { imgSource: img3 },
  { imgSource: img4 },
  { imgSource: img5 },
  { imgSource: img6 },
];
