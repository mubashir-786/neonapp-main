export default function StepsSection() {
  return (
    <div>
      <h2 className="text-2xl font-bold text-pink text-center">
        Create a custom neon sign in 5 easy steps
      </h2>
    </div>
  );
}
